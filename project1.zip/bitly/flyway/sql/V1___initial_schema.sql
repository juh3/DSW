CREATE TABLE shortenings (
  id SERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  string TEXT NOT NULL
)